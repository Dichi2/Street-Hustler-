require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const nodemailer = require('nodemailer');

const app = express();
const PORT = Number(process.env.PORT || 8080);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error('JWT_SECRET must be at least 32 characters');
const db = new Database(process.env.DB_FILE || './street-hustle.db');
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 game_name TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 email_verified INTEGER NOT NULL DEFAULT 0,
 token_version INTEGER NOT NULL DEFAULT 0,
 failed_logins INTEGER NOT NULL DEFAULT 0,
 locked_until INTEGER,
 created_at INTEGER NOT NULL,
 updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS verification_tokens (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 token_hash TEXT NOT NULL UNIQUE,
 expires_at INTEGER NOT NULL,
 used INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS reset_tokens (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 token_hash TEXT NOT NULL UNIQUE,
 expires_at INTEGER NOT NULL,
 used INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS game_state (
 user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 state_json TEXT NOT NULL,
 updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS listings (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 seller_id INTEGER NOT NULL REFERENCES users(id),
 asset_type TEXT NOT NULL,
 asset_name TEXT NOT NULL,
 price INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'OPEN',
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS contracts (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 employer_id INTEGER NOT NULL REFERENCES users(id),
 worker_id INTEGER REFERENCES users(id),
 job TEXT NOT NULL,
 salary INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'OPEN',
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS disputes (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 reporter_id INTEGER NOT NULL REFERENCES users(id),
 type TEXT NOT NULL,
 details TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'PENDING',
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id),
 action TEXT NOT NULL,
 delta INTEGER NOT NULL,
 balance_after INTEGER NOT NULL,
 request_id TEXT,
 created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_transactions_user_time ON transactions(user_id,created_at);
CREATE TABLE IF NOT EXISTS action_requests (
 user_id INTEGER NOT NULL REFERENCES users(id),
 request_id TEXT NOT NULL,
 response_json TEXT NOT NULL,
 created_at INTEGER NOT NULL,
 PRIMARY KEY(user_id,request_id)
);
`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',').map(s => s.trim()) : true }));
app.use(express.json({ limit: '100kb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: true, legacyHeaders: false }));

const authLimit = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
const now = () => Date.now();
const sha = v => crypto.createHash('sha256').update(v).digest('hex');
const randomToken = () => crypto.randomBytes(32).toString('hex');

const cities = [
 ['Lagos','Nigeria','Africa',0],['Nairobi','Kenya','Africa',1500],['Johannesburg','South Africa','Africa',2500],['Cairo','Egypt','Africa',3500],
 ['London','UK','Europe',0],['Paris','France','Europe',2500],['Berlin','Germany','Europe',3000],['Istanbul','Türkiye','Europe/Asia',4000],
 ['New York','USA','North America',4500],['Los Angeles','USA','North America',5500],['Toronto','Canada','North America',5000],['Mexico City','Mexico','North America',5000],
 ['São Paulo','Brazil','South America',6500],['Buenos Aires','Argentina','South America',7000],['Bogotá','Colombia','South America',6500],
 ['Dubai','UAE','Asia',5000],['Tokyo','Japan','Asia',7000],['Singapore','Singapore','Asia',7500],['Mumbai','India','Asia',6000],['Seoul','South Korea','Asia',7500],
 ['Sydney','Australia','Oceania',9000],['Auckland','New Zealand','Oceania',9500]
];
const cityMap = new Map(cities.map(c => [c[0], c]));
const props = [['Starter Room',1500,1],['City Apartment',8000,3],['Street Shop',15000,5],['Small Office',35000,10],['Hotel',150000,25],['Factory',500000,35]];
const cars = [['Delivery Motorcycle',2500,1],['Street Sedan',9000,3],['Delivery Van',22000,5],['Luxury SUV',80000,15],['Private Jet',1000000,40]];
const stockBase = [['DI Logistics',100],['Lagos Foods',70],['Global Tech',150],['Street Motors',90]];
const defaultState = city => ({
 sc:5000, level:1, jobs:0, city, cities:[city], continent:cityMap.get(city)?.[2] || 'Africa',
 business:'None', bizValue:0, npc:0, pworkers:0, points:0, props:[], cars:[], contracts:[], portfolio:[],
 stocks:stockBase.map(x=>({name:x[0],price:x[1],owned:0})), workerRep:100, employerRep:100, purchaseRep:100, court:[], lastJobAt:0, missions:{}, heat:0
});

function publicUser(u){ return { id:u.id, email:u.email, gameName:u.game_name, emailVerified:!!u.email_verified, createdAt:u.created_at }; }
function sign(u){ return jwt.sign({ sub:u.id, tv:u.token_version }, JWT_SECRET, { expiresIn:'7d', issuer:'street-hustle' }); }
function requireAuth(req,res,next){
 try {
  const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Authentication required'});
  const p=jwt.verify(h.slice(7), JWT_SECRET, {issuer:'street-hustle'}); const u=db.prepare('SELECT * FROM users WHERE id=?').get(p.sub);
  if(!u || u.token_version!==p.tv) return res.status(401).json({error:'Session expired'}); req.user=u; next();
 } catch(e){ return res.status(401).json({error:'Invalid or expired session'}); }
}
function getState(uid){ const r=db.prepare('SELECT state_json FROM game_state WHERE user_id=?').get(uid); return r?JSON.parse(r.state_json):null; }
function putState(uid,state){ const t=now(); db.prepare(`INSERT INTO game_state(user_id,state_json,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET state_json=excluded.state_json,updated_at=excluded.updated_at`).run(uid,JSON.stringify(state),t); }
function logTx(uid,action,delta,balance,requestId=null){ db.prepare('INSERT INTO transactions(user_id,action,delta,balance_after,request_id,created_at) VALUES(?,?,?,?,?,?)').run(uid,action,delta,balance,requestId,now()); }
function requestId(req){ const v=String(req.headers['x-idempotency-key']||'').trim(); return v && v.length<=100 ? v : null; }
function getSavedAction(uid,rid){ if(!rid)return null; const r=db.prepare('SELECT response_json FROM action_requests WHERE user_id=? AND request_id=?').get(uid,rid); return r?JSON.parse(r.response_json):null; }

function issueToken(table,userId,minutes){ const raw=randomToken(); db.prepare(`INSERT INTO ${table}(user_id,token_hash,expires_at) VALUES(?,?,?)`).run(userId,sha(raw),now()+minutes*60*1000); return raw; }
async function sendMail(to,subject,text){
 if(!process.env.SMTP_HOST){ console.log(`[DEV EMAIL] to=${to}\n${subject}\n${text}`); return; }
 const transporter=nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==='true',auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
 await transporter.sendMail({from:process.env.MAIL_FROM||'Street Hustle <no-reply@example.com>',to,subject,text});
}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'street-hustle',time:now()}));

app.get('/reset-password',(req,res)=>res.type('html').send(`<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>Street Hustle Password Reset</title><style>body{font-family:Arial;max-width:520px;margin:40px auto;padding:20px;background:#171e27;color:white}input,button{width:100%;padding:12px;margin:8px 0;border-radius:8px;border:0}button{background:#f0b90b;font-weight:bold}</style><h2>Street Hustle Password Reset</h2><p>Choose a new password.</p><input id=p type=password placeholder="New password (10+ chars, letter + number)"><button onclick="go()">Reset Password</button><p id=m></p><script>const token=new URLSearchParams(location.search).get('token');async function go(){const r=await fetch('/api/auth/reset-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,password:p.value})});const j=await r.json();m.textContent=j.message||j.error}</script>`));


app.post('/api/auth/register', authLimit, async (req,res)=>{
 const email=String(req.body.email||'').trim().toLowerCase(); const gameName=String(req.body.gameName||'').trim(); const password=String(req.body.password||''); const startingCity=String(req.body.startingCity||'');
 if(!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({error:'Enter a valid email address'});
 if(!/^[A-Za-z0-9_ -]{3,20}$/.test(gameName)) return res.status(400).json({error:'Game name must be 3-20 letters, numbers, spaces, _ or -'});
 if(password.length<10 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) return res.status(400).json({error:'Password must be at least 10 characters and include a letter and number'});
 if(!cityMap.has(startingCity)) return res.status(400).json({error:'Choose a valid starting city'});
 try {
  const hash=await bcrypt.hash(password,12); const t=now(); const info=db.prepare('INSERT INTO users(email,game_name,password_hash,created_at,updated_at) VALUES(?,?,?,?,?)').run(email,gameName,hash,t,t);
  const uid=info.lastInsertRowid; putState(uid,defaultState(startingCity)); const token=issueToken('verification_tokens',uid,60*24); const base=process.env.APP_BASE_URL||`http://localhost:${PORT}`;
  await sendMail(email,'Verify your Street Hustle account',`Welcome to Street Hustle, ${gameName}! Verify your account here:\n${base}/api/auth/verify-email?token=${token}`);
  res.status(201).json({user:publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(uid)),message:'Account created. Check your email to verify it.',verificationToken:process.env.NODE_ENV==='production'?undefined:token});
 } catch(e){ if(String(e.message).includes('UNIQUE')) return res.status(409).json({error:'Email or game name is already in use'}); console.error(e); res.status(500).json({error:'Could not create account'}); }
});

app.get('/api/auth/verify-email', async (req,res)=>{
 const token=String(req.query.token||''); const row=db.prepare('SELECT * FROM verification_tokens WHERE token_hash=? AND used=0 AND expires_at>?').get(sha(token),now());
 if(!row) return res.status(400).send('Verification link is invalid or expired.');
 db.transaction(()=>{db.prepare('UPDATE verification_tokens SET used=1 WHERE id=?').run(row.id); db.prepare('UPDATE users SET email_verified=1,updated_at=? WHERE id=?').run(now(),row.user_id);})();
 res.send('Street Hustle account verified. You can return to the game and sign in.');
});

app.post('/api/auth/login', authLimit, async (req,res)=>{
 const email=String(req.body.email||'').trim().toLowerCase(); const password=String(req.body.password||''); const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);
 if(!u) return res.status(401).json({error:'Invalid email or password'});
 if(u.locked_until && u.locked_until>now()) return res.status(429).json({error:'Account temporarily locked. Try again later.'});
 const ok=await bcrypt.compare(password,u.password_hash);
 if(!ok){ const fails=u.failed_logins+1; db.prepare('UPDATE users SET failed_logins=?,locked_until=?,updated_at=? WHERE id=?').run(fails,fails>=5?now()+15*60*1000:null,now(),u.id); return res.status(401).json({error:'Invalid email or password'}); }
 db.prepare('UPDATE users SET failed_logins=0,locked_until=NULL,updated_at=? WHERE id=?').run(now(),u.id);
 res.json({token:sign(u),user:publicUser(u),state:getState(u.id),requiresVerification:!u.email_verified});
});

app.post('/api/auth/forgot-password', authLimit, async (req,res)=>{
 const email=String(req.body.email||'').trim().toLowerCase(); const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);
 if(u){ const token=issueToken('reset_tokens',u.id,30); const base=process.env.APP_BASE_URL||`http://localhost:${PORT}`; await sendMail(email,'Reset your Street Hustle password',`Reset your password here:\n${base}/reset-password?token=${token}\nThis link expires in 30 minutes.`); }
 res.json({message:'If an account exists for that email, password-reset instructions have been sent.'});
});

app.post('/api/auth/reset-password', authLimit, async (req,res)=>{
 const token=String(req.body.token||''); const password=String(req.body.password||'');
 if(password.length<10 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) return res.status(400).json({error:'Password must be at least 10 characters and include a letter and number'});
 const row=db.prepare('SELECT * FROM reset_tokens WHERE token_hash=? AND used=0 AND expires_at>?').get(sha(token),now()); if(!row) return res.status(400).json({error:'Reset token is invalid or expired'});
 const hash=await bcrypt.hash(password,12); db.transaction(()=>{db.prepare('UPDATE reset_tokens SET used=1 WHERE id=?').run(row.id); db.prepare('UPDATE users SET password_hash=?,token_version=token_version+1,failed_logins=0,locked_until=NULL,updated_at=? WHERE id=?').run(hash,now(),row.user_id);})();
 res.json({message:'Password reset. All previous sessions were signed out.'});
});

app.get('/api/me',requireAuth,(req,res)=>res.json({user:publicUser(req.user),state:getState(req.user.id)}));
app.post('/api/auth/logout-all',requireAuth,(req,res)=>{db.prepare('UPDATE users SET token_version=token_version+1,updated_at=? WHERE id=?').run(now(),req.user.id);res.json({message:'All sessions signed out'});});

app.post('/api/state',requireAuth,(req,res)=>{ return res.status(400).json({error:'Direct state writes are disabled. Use game actions so the server can validate them.'}); });
app.get('/api/state',requireAuth,(req,res)=>res.json({state:getState(req.user.id)}));

app.post('/api/game/action',requireAuth,(req,res)=>{
 const action=String(req.body.action||''); const payload=req.body.payload||{}; const uid=req.user.id; const rid=requestId(req); let result; const saved=getSavedAction(uid,rid); if(saved) return res.json(saved);
 try {
  result=db.transaction(()=>{
   const s=getState(uid); if(!s) throw new Error('Game state missing');
   if(action==='job'){
    if(now()-Number(s.lastJobAt||0)<5000) throw new Error('Please wait before taking another job');
    const heat=Number(s.heat||0); const reward=Math.max(250,750-Math.floor(heat*2)); s.sc+=reward; s.jobs++; s.points+=50; s.heat=Math.max(0,heat-2); s.lastJobAt=now(); if(s.jobs%3===0){s.level++;s.sc+=s.level*250;s.points+=s.level*100;} result={message:`Delivery complete: +${reward} SC`};
   } else if(action==='playerJob'){
    if(s.level<3) throw new Error('Player jobs unlock at Level 3'); s.sc+=2000;s.jobs++;s.points+=120;s.workerRep=Math.min(100,s.workerRep+1); result={message:'Player contract job completed: +2,000 SC'};
   } else if(action==='startBusiness'){
    if(s.level<5) throw new Error('Business ownership unlocks at Level 5'); const cost=s.business==='None'?3000:Math.min(100000,Math.floor(s.bizValue*.25+2000)); if(s.sc<cost) throw new Error(`Need ${cost} SC`);s.sc-=cost;if(s.business==='None'){s.business='Street Hustle Shop';s.bizValue=5000}else s.bizValue+=cost*2;s.points+=300;result={message:'Business upgraded'};
   } else if(action==='hireNPC'){
    if(s.level<10) throw new Error('NPC hiring unlocks at Level 10'); if(s.sc<1000) throw new Error('Not enough SC');s.sc-=1000;s.npc++;s.bizValue+=500;s.employerRep=Math.min(100,s.employerRep+1);result={message:'NPC worker hired'};
   } else if(action==='coolHeat'){ const cost=250; if((s.heat||0)<=0) throw new Error('Your heat is already zero'); if(s.sc<cost) throw new Error('Need 250 SC to lay low'); s.sc-=cost; s.heat=Math.max(0,(s.heat||0)-15); result={message:'You laid low and reduced heat'};
   } else if(action==='buyAsset'){
    const type=String(payload.type||''); const i=Number(payload.index); const list=type==='property'?props:cars; const x=list[i]; if(!x) throw new Error('Invalid asset'); if(s.level<x[2]) throw new Error(`Reach Level ${x[2]} first`); if(s.sc<x[1]) throw new Error('Not enough SC'); s.sc-=x[1]; (type==='property'?s.props:s.cars).push({name:x[0],price:x[1]});s.points+=type==='property'?80:50;result={message:`Purchased ${x[0]}`};
   } else if(action==='sellAsset'){
    const type=String(payload.type||''); const i=Number(payload.index); const arr=type==='property'?s.props:s.cars; const x=arr[i]; if(!x) throw new Error('Asset not found'); const rate=type==='property'?.65:.60; const r=Math.floor(x.price*rate);s.sc+=r;arr.splice(i,1);s.points=Math.max(0,s.points-(type==='property'?20:0));result={message:`Sold for ${r} SC`};
   } else if(action==='travel'){
    const c=String(payload.city||''); const x=cityMap.get(c); if(!x) throw new Error('Invalid city'); if(s.level<20 && x[3]>0) throw new Error('International travel unlocks at Level 20'); if(s.sc<x[3]) throw new Error(`Need ${x[3]} SC for travel`);s.sc-=x[3];if(!s.cities.includes(c))s.cities.push(c);s.city=c;s.continent=x[2];s.points+=150;result={message:`Travelled to ${c}`};
   } else if(action==='invest'){
    const i=Number(payload.index); const qty=10; const st=s.stocks[i]; if(!st) throw new Error('Invalid stock'); const cost=st.price*qty;if(s.sc<cost) throw new Error(`Need ${cost} SC`);s.sc-=cost;st.owned+=qty;s.portfolio.push({name:st.name,qty,cost});s.points+=60;result={message:`Bought ${qty} shares`};
   } else if(action==='marketTick'){
    s.stocks.forEach(st=>{const change=(Math.random()-.45)*.18;st.price=Math.max(10,Math.round(st.price*(1+change)))});result={message:'Market prices updated'};
   } else if(action==='fileDispute'){
    const type=String(payload.type||'General dispute').slice(0,80); const details=String(payload.details||'').slice(0,1000); db.prepare('INSERT INTO disputes(reporter_id,type,details,created_at) VALUES(?,?,?,?)').run(uid,type,details,now());s.court.push({type,result:'Pending review'});s.points+=5;result={message:'Case submitted to Game Court'};
   } else throw new Error('Unknown game action');
   putState(uid,s); logTx(uid,action,0,s.sc,rid); return {state:s,result};
  })();
  if(rid) db.prepare('INSERT INTO action_requests(user_id,request_id,response_json,created_at) VALUES(?,?,?,?)').run(uid,rid,JSON.stringify(result),now()); res.json(result);
 } catch(e){res.status(400).json({error:e.message});}
});

const missionDefs={
 'First Steps':s=>s.jobs>=1,
 'Road Warrior':s=>s.jobs>=10,
 'Level Up':s=>s.level>=10,
 'Global Citizen':s=>s.cities.length>=5,
 'Entrepreneur':s=>s.business!=='None',
 'Property Tycoon':s=>s.props.length>=3,
 'Wheel Dealer':s=>s.cars.length>=3,
 'Market Player':s=>s.portfolio.reduce((a,x)=>a+(x.qty||0),0)>=30
};
const missionRewards={'First Steps':100,'Road Warrior':500,'Level Up':750,'Global Citizen':1000,'Entrepreneur':800,'Property Tycoon':1200,'Wheel Dealer':1000,'Market Player':900};
app.post('/api/missions/claim',requireAuth,(req,res)=>{try{const name=String(req.body.name||'');if(!missionDefs[name])throw new Error('Unknown mission');const out=db.transaction(()=>{const s=getState(req.user.id);s.missions=s.missions||{};if(s.missions[name])throw new Error('Mission already claimed');if(!missionDefs[name](s))throw new Error('Mission not complete');const reward=missionRewards[name];s.sc+=reward;s.points+=Math.floor(reward/5);s.missions[name]=now();putState(req.user.id,s);logTx(req.user.id,'mission:'+name,reward,s.sc);return s;})();res.json({state:out,message:`Mission completed — +${missionRewards[name]} SC`});}catch(e){res.status(400).json({error:e.message});}});

app.get('/api/world',requireAuth,(req,res)=>{
 const leaders=db.prepare(`SELECT u.game_name, json_extract(g.state_json,'$.points') AS points, json_extract(g.state_json,'$.level') AS level, json_extract(g.state_json,'$.city') AS city FROM users u JOIN game_state g ON g.user_id=u.id ORDER BY points DESC LIMIT 25`).all();
 res.json({cities,properties:props,cars,leaders});
});

app.get('/api/market/listings',requireAuth,(req,res)=>{
 const rows=db.prepare(`SELECT l.id,l.asset_type,l.asset_name,l.price,l.created_at,u.game_name AS seller FROM listings l JOIN users u ON u.id=l.seller_id WHERE l.status='OPEN' ORDER BY l.created_at DESC LIMIT 50`).all();res.json({listings:rows});
});
app.post('/api/market/listings',requireAuth,(req,res)=>{
 const assetType=String(req.body.assetType||''); const assetName=String(req.body.assetName||''); const price=Number(req.body.price); if(!['property','vehicle'].includes(assetType)||!assetName||!Number.isInteger(price)||price<1||price>100000000) return res.status(400).json({error:'Invalid listing'});
 const s=getState(req.user.id); const arr=assetType==='property'?s.props:s.cars; const idx=arr.findIndex(x=>x.name===assetName); if(idx<0) return res.status(400).json({error:'You do not own that asset'}); const info=db.prepare('INSERT INTO listings(seller_id,asset_type,asset_name,price,created_at) VALUES(?,?,?,?,?)').run(req.user.id,assetType,assetName,price,now());res.status(201).json({id:info.lastInsertRowid});
});
app.post('/api/market/listings/:id/buy',requireAuth,(req,res)=>{
 try{const out=db.transaction(()=>{const l=db.prepare("SELECT * FROM listings WHERE id=? AND status='OPEN'").get(req.params.id);if(!l)throw new Error('Listing unavailable');if(l.seller_id===req.user.id)throw new Error('You cannot buy your own listing');const buyer=getState(req.user.id);const seller=getState(l.seller_id);if(buyer.sc<l.price)throw new Error('Not enough SC');const arr=l.asset_type==='property'?seller.props:seller.cars;const idx=arr.findIndex(x=>x.name===l.asset_name);if(idx<0)throw new Error('Seller no longer owns this asset');const asset=arr.splice(idx,1)[0];buyer.sc-=l.price;seller.sc+=l.price;(l.asset_type==='property'?buyer.props:buyer.cars).push({...asset,price:l.price});buyer.purchaseRep=Math.min(100,buyer.purchaseRep+2);seller.purchaseRep=Math.min(100,seller.purchaseRep+1);db.prepare("UPDATE listings SET status='SOLD' WHERE id=?").run(l.id);putState(req.user.id,buyer);putState(l.seller_id,seller);return buyer;})();res.json({state:out,message:'Purchase completed'});}catch(e){res.status(400).json({error:e.message});}
});

app.post('/api/contracts',requireAuth,(req,res)=>{const job=String(req.body.job||'Delivery Contract').slice(0,100);const salary=Number(req.body.salary);if(!Number.isInteger(salary)||salary<500) return res.status(400).json({error:'Invalid salary'});const s=getState(req.user.id);if(s.level<15)return res.status(400).json({error:'Player hiring unlocks at Level 15'});if(s.sc<salary)return res.status(400).json({error:'Not enough SC for escrow'});s.sc-=salary;s.pworkers++;s.contracts.push({job,salary,status:'OPEN'});putState(req.user.id,s);const info=db.prepare('INSERT INTO contracts(employer_id,job,salary,created_at) VALUES(?,?,?,?)').run(req.user.id,job,salary,now());res.status(201).json({id:info.lastInsertRowid,state:s});});
app.get('/api/contracts',requireAuth,(req,res)=>res.json({contracts:db.prepare(`SELECT c.id,c.job,c.salary,c.status,u.game_name AS employer FROM contracts c JOIN users u ON u.id=c.employer_id WHERE c.status='OPEN' ORDER BY c.created_at DESC LIMIT 50`).all()}));

app.post('/api/contracts/:id/accept',requireAuth,(req,res)=>{
 try{const out=db.transaction(()=>{const c=db.prepare("SELECT * FROM contracts WHERE id=? AND status='OPEN'").get(req.params.id);if(!c)throw new Error('Contract unavailable');if(c.employer_id===req.user.id)throw new Error('You cannot accept your own contract');const worker=getState(req.user.id);const employer=getState(c.employer_id);if(worker.level<3)throw new Error('Player jobs unlock at Level 3');worker.sc+=c.salary;worker.jobs++;worker.points+=120;worker.workerRep=Math.min(100,worker.workerRep+1);employer.pworkers=Math.max(0,(employer.pworkers||0)-1);employer.employerRep=Math.min(100,(employer.employerRep||100)+1);const status="ACCEPTED";db.prepare('UPDATE contracts SET worker_id=?,status=? WHERE id=?').run(req.user.id,status,c.id);putState(req.user.id,worker);putState(c.employer_id,employer);return worker;})();res.json({state:out,message:'Contract accepted and escrow salary paid'});}catch(e){res.status(400).json({error:e.message});}
});


app.get('/api/account/activity',requireAuth,(req,res)=>{
 const rows=db.prepare('SELECT action,delta,balance_after,created_at FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 100').all(req.user.id);
 res.json({transactions:rows});
});

app.post('/api/daily-reward',requireAuth,(req,res)=>{
 try { const out=db.transaction(()=>{ const s=getState(req.user.id); const day=Math.floor(now()/86400000); if(Number(s.dailyRewardDay)===day) throw new Error('Daily reward already claimed'); const amount=500+Math.min(1500,(s.level||1)*50); s.sc+=amount; s.points+=25; s.dailyRewardDay=day; putState(req.user.id,s); logTx(req.user.id,'dailyReward',amount,s.sc); return s; })(); res.json({state:out,message:'Daily reward claimed'}); } catch(e){res.status(400).json({error:e.message});}
});

app.post('/api/bank',requireAuth,(req,res)=>{
 const action=String(req.body.action||''); const amount=Number(req.body.amount); if(!Number.isInteger(amount)||amount<=0||amount>100000000) return res.status(400).json({error:'Invalid amount'});
 try { const out=db.transaction(()=>{ const s=getState(req.user.id); s.bank=Number(s.bank||0); if(action==='deposit'){if(s.sc<amount)throw new Error('Not enough SC');s.sc-=amount;s.bank+=amount;logTx(req.user.id,'bankDeposit',-amount,s.sc);} else if(action==='withdraw'){if(s.bank<amount)throw new Error('Insufficient bank balance');s.bank-=amount;s.sc+=amount;logTx(req.user.id,'bankWithdraw',amount,s.sc);} else throw new Error('Unknown bank action'); putState(req.user.id,s); return s;})(); res.json({state:out,message:action==='deposit'?'Deposited SC':'Withdrew SC'}); } catch(e){res.status(400).json({error:e.message});}
});

app.get('/api/achievements',requireAuth,(req,res)=>{ const s=getState(req.user.id); const defs=[['First Job',s.jobs>=1,50],['Level 10',s.level>=10,250],['Globetrotter',s.cities.length>=5,500],['Business Owner',s.business!=='None',300],['Property Collector',s.props.length>=3,400],['Market Trader',s.portfolio.reduce((a,x)=>a+(x.qty||0),0)>=30,350]]; res.json({achievements:defs.map(x=>({name:x[0],unlocked:x[1],reward:x[2]}))}); });

app.get('/api/admin/metrics',(req,res)=>{ if(!process.env.ADMIN_KEY || req.headers['x-admin-key']!==process.env.ADMIN_KEY) return res.status(403).json({error:'Forbidden'}); const users=db.prepare('SELECT COUNT(*) n FROM users').get().n; const verified=db.prepare('SELECT COUNT(*) n FROM users WHERE email_verified=1').get().n; const tx=db.prepare('SELECT COUNT(*) n FROM transactions').get().n; res.json({users,verified,transactions:tx,uptime:process.uptime(),time:now()}); });

app.listen(PORT,()=>console.log(`Street Hustle backend listening on :${PORT}`));
